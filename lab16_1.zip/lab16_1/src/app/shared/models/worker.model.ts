export interface Worker {
  id: number;
  lastname: string;
  name: string;
  surname: string;
  number: string;
  email: string;
  DOB: Date;
  department: string;
}
